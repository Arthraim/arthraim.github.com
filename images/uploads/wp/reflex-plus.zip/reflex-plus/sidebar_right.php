<div id="primary" class="sidebar">
	<div id="sidebar-wrap">

	<ul class="xoxo">
	<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Right sidebar') ) : // begin primary sidebar widgets ?>	

	<?php endif; // end primary sidebar widgets  ?>
	</ul>
</div><!-- #primary .sidebar -->

</div><!-- #secondary .sidebar -->