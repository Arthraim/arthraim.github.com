<div id="footer">
</div>

<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>
<?php wp_footer() ?>
</body>
</html>